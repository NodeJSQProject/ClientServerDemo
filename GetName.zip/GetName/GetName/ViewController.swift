//
//  ViewController.swift
//  GetName
//
//  Created by quynhbkhn on 12/18/17.
//  Copyright © 2017 quynhbkhn. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var btnPushBook: UIButton!
    @IBOutlet weak var txtBookName: UITextField!
    @IBOutlet weak var tableView: UITableView!
    
    var arrName: Array<String> = []
    
    @IBAction func onPushBookTouched(_ sender: Any) {
        let name : String = txtBookName.text!
        let param = "name=\(name)"
      
        let paramData = param.data(using: String.Encoding.utf8)
        let url = URL(string: "http://localhost:5000/insert")
        var urlReq = URLRequest(url: url!)
        
        urlReq.httpMethod = "POST"
        urlReq.httpBody = paramData
        
        let session = URLSession.shared
        session.dataTask(with: urlReq, completionHandler: {(data, res, err) in
            if err == nil {
                self.loadData()
                self.tableView.reloadData()
            }
        }).resume()
        
        self.tableView.reloadData()
    }
    
    func loadData() {
        let url = URL(string: "http://localhost:5000/getList")
        let urlReq = URLRequest(url: url!)
    
        
        let session = URLSession.shared
        session.dataTask(with: urlReq, completionHandler: {
            (data, res, err) in
            do {
                if data == nil {
                    print("please run your server!\n")
                    return
                }
                
                let result = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as! Array<String>
                self.arrName = result
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            } catch{}
        }).resume()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        loadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return self.arrName.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        cell?.textLabel?.text = arrName[indexPath.row]
        return cell!
    }
    
}

